<html>
<head>
<title>Login</title>
</head>

<body>


<?php
// check to make sure that the site is secure
//if ($_SERVER["HTTP_HOST"]!="secure.hosting.vt.edu") {
//Header("Location: https://secure.hosting.vt.edu/".$_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"]);
//}
?>
<br>
<h3 style="text-align: center;">Formul&aacute;rio de Login para Reserva da Sala de Reuni&otilde;es</p>

<!-- create the “main” form with an input text box named pid and a password text box named password -->

<form name="main" method="post" action="principal.php">
<table align="center">
<tr>
<td align="center">Usu&aacute;rio: </td>
<td> <input name="pid" type="text" id="pid"> </td>
</tr>
<tr>
<td align="center">Senha: </td>
<td> <input name="password" type="password" id="password"> </td>
</tr>
<tr>

<td align="center" colspan="2">
<input name="ano" type="hidden" id="ano" <?php echo('value="'.date('Y').'"'); ?> >
<input name="mes" type="hidden" id="mes" <?php echo('value="'.date('m').'"'); ?> >
<input name="dia" type="hidden" id="dia" <?php echo('value="'.date('d').'"'); ?> >
<input name="btnsubmit" type="submit" value="Enviar Credenciais"></td>
</tr>
</table>
</form>

</body>
</html>
