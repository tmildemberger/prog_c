<html>
<head><title>Reservas</title>
<style type="text/css">
    table {border-collapse:collapse}
</style>
</head>
<body>
<?php

$nome = $_POST['nome'];
$data = $_POST['data'];
$hora_ini = $_POST['hora_ini'];
$hora_fim = $_POST['hora_fim'];

$horas = $hora_fim - $hora_ini;

if ($horas < 1){

} else {
    for ($i = $hora_ini; $i < ($hora_ini + $horas); $i++){
        include 'conecta.php';
        
        $comando = pg_query("SELECT * FROM reservas WHERE data = '".$data."' AND hora = '".$i."';");
        $re=pg_fetch_array($comando);
        if ($re){
        
        } else {
            pg_query("INSERT INTO reservas VALUES ('".$nome."', '".$data."', '".$i."');");
        }
    }
}

                                echo('<br><h2 style="text-align: center;">Bem vindo &agrave reserva da Sala de Reuni&atildeo, <br>'.$usuario.'</h1><br>
                                     <table align="center" border=1>
                                     <tbody>
                                     <tr>
                                     <td style="size:5">Selecione o hor&aacuterio da reserva:</td>
                                     <form id="m_opt_form" action="reservar.php" method="post"><td>
                                     <select name="horario_ini" >
                                     <option value="">Começo</option>');


?>
</body>
</html>
