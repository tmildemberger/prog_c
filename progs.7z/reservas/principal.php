<html>
<head><title>Reservas</title>
<style type="text/css">
    table {border-collapse:collapse}
</style>
<script language="javascript">
    function send(str){
        document.getElementById(str).submit();
    }
</script>
</head>
<body>
<?php
$host = 'ldaps://ldapslave.ct.utfpr.edu.br/';
$baseDn = 'dc=utfpr,dc=edu,dc=br';
$pid = $_POST['pid'];
$credential = $_POST['password'];
$master='false';

$ano = $_POST['ano'];
$mes = $_POST['mes'];
$dia = $_POST['dia'];

$data = (($ano) * 100 + $mes) * 100 + $dia;

//$PCLIGADO=null;
session_start();
if (empty($_POST['password']))
{
    $credential = $_SESSION['credential'];
}
else
{
    $_SESSION['credential'] = $_POST['password'];
}

    /*ldap will bind anonymously, make sure we have some credentials*/
    if (isset($pid) && $pid != '' && isset($credential))
    {
        $ldap = ldap_connect($host);
        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_start_tls($ldap);
        if (isset($ldap) && $ldap != '')
        {
            /* search for pid dn */
            $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('dn'));
            if ($result != 0)
            {
                $entries = ldap_get_entries($ldap, $result);
                $principal = $entries[0]['dn'];
                $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('cn'));
                $entries = ldap_get_entries($ldap, $result);
                $usuario = $entries[0]['cn'][0];
                if (isset($principal))
                {
                    /* bind as this user */
                    if (@ldap_bind($ldap, $principal, $credential))
                    {
                        if ($cadastro != "true")
                        {
                            include 'conecta.php';
                            if($connect)
                            {
                                $comando = pg_query("SELECT * FROM acesso");
                                $matriz_resposta=pg_fetch_array($comando);
                                while ($matriz_resposta)
                                {
                                    $nome = $matriz_resposta['adm'];
                                    $nome = (trim($nome));
                                    if ( $nome == $pid )
                                    {
                                        $adm = 'false';
                                        $master='true';
                                        $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('cn'));
                                        $entries = ldap_get_entries($ldap, $result);
                                        $usuario = $entries[0]['cn'][0];
                                    }
                                    $matriz_resposta=pg_fetch_array($comando);
                                }
                                
                                
                            }

                            else
                            {
                                echo('<br><h2 style="text-align: center;">Bem vindo &agrave reserva da Sala de Reuni&atildeo, <br>'.$usuario.'</h1><br>
                                     <table align="center">
                                     <tbody>
                                     <tr><td style="size:5">Erro ao acessar o banco de dados psql, favor verificar o problema</td></tr>
                                     <tr><td style="size:5">ou contactar um respons&aacutevel.</td>
                                     </tr></tbody></table>');
                            }
                            if($master=='true')
                            {
                                echo('<br><h2 style="text-align: center;">Bem vindo &agrave reserva da Sala de Reuni&atildeo, <br>'.$usuario.'</h1><br>
                                     <table align="center" border=1>
                                     <tbody>
                                     <tr>
                                     <td style="size:5">Selecione o hor&aacuterio da reserva:</td>
                                     <form id="m_opt_form" action="reservar.php" method="post"><td>
                                     <select name="hora_ini" >
                                     <option value="">Começo</option>');
                                for ($i = 7; $i <= 23; $i++){
                                    echo('<option value="'.$i.'">'.$i.'h</option>');
                                }
                                     echo('</select>
                                     <select name="hora_fim" >
                                     <option value="">Término (não incluído na reserva)</option>');
                                for ($i = 7; $i <= 23; $i++){
                                    echo('<option value="'.$i.'">'.$i.'h</option>');
                                }
                                     echo('</select>
                                     </td> <td>
                                     <input name="data" type="hidden" value='.sprintf("%04d-%02d-%02d", $ano,$mes,$dia).'>
                                     <input name="nome" type="hidden" value="'.$usuario.'">
                                     
                                     <input name"btreserva" type="submit" value="Reservar"></td> </form> </tr> </tbody> </table>');
                                     
                                      echo('<table align="center" border="1">
                                            <tbody><tr><td>Dia '.sprintf("%02d/%02d/%04d", $dia,$mes,$ano).'</td><td>Estado</td></tr>');
                                for ($i = 7; $i <= 23; $i++){
                                    echo('<tr><td>'.$i.'h</td><td>');
                                    $comando = pg_query("SELECT * FROM reservas WHERE data = '".$data."' AND hora = '".$i."';");
                                    $re=pg_fetch_array($comando);
                                    if ($re){
                                        echo('reservado por '.$re['prof']);
                                    } else {
                                        echo('não reservado');
                                    }
                                    echo('</td></tr>');
                                }
                                     echo('</tbody></table>');
                            }
                            //pg_close($connect);

                            
                            
                        }
                        else
                        {
                            echo "Cadastro";
                            unset($_SESSION['credential']);
                            //include ''
                        }
                    }
                    else
                    {
                        print('Falha na Autentica&ccedil;&atilde;o');
                        header("Location: negado.html");
                    }
                }
                else
                {
                    ldap_free_result($result);
                    ldap_close($ldap);
                    //print('Usu&aacute;rio n&atilde;o encontrado na Base LDAP');
                    header("Location: negado.html");
                }
                ldap_free_result($result);

            }
            else
            {
                ldap_close($ldap);
                //print('Erro ocorreu na busca da Base LDAP');
                header("Location: negado.html");
            }
            ldap_close($ldap);
        }
        else
        {
            //print('N&atilde;o foi poss&iacute;vel conectar ao host '.$host);
            header("Location: negado.html");
        }
        //echo('<p>passou aqui</p>');
    }
    else
    {
        header("Location: negado.html");
    }


//function 

?>
</body>
</html>
