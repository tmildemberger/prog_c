<?php
$string_connect = "host=localhost port=5432 dbname=horario user=tecnico password=t&cn1c0.";
$connect = pg_connect($string_connect);
?>
