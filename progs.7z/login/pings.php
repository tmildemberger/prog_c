<html>
<head>
<script type="text/javascript">
function closeSelf(){
    self.close();
    return true;
}
</script>
<title>Gerenciador de M&aacute;quinas</title></head>
<body>
<html>
<head><title>NAO USE A MENOS QUE SAIBA O QUE ESTA FAZENDO</title></head>
<body>
<?php
$host = 'ldaps://ldapslave.ct.utfpr.edu.br/';
$baseDn = 'dc=utfpr,dc=edu,dc=br';
$pid = $_POST['pid']; // get these values explicitly from the POST
$credential = $_POST['password'];
$acao = $_POST[acao];
$cadastro = $_POST[cadastro];

session_start();
if (empty($_POST['password']))
{
    $credential = $_SESSION['credential'];
}
else
{
    $_SESSION['credential'] = $_POST['password'];
}
/*if ( $pid == 'utfpr-ct23' || $pid == 'vagnerg' || $pid == 'kovalhuk' )
{
    $adm = 'true';
}*/




    /*ldap will bind anonymously, make sure we have some credentials*/
    if (isset($pid) && $pid != '' && isset($credential)) 
    {
        $ldap = ldap_connect($host);
        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_start_tls($ldap);
        if (isset($ldap) && $ldap != '') 
        {
            /* search for pid dn */
            $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('dn'));
            if ($result != 0) 
            {
                $entries = ldap_get_entries($ldap, $result);
                $principal = $entries[0]['dn'];
                if (isset($principal)) 
                {
                    /* bind as this user */
                    if (@ldap_bind($ldap, $principal, $credential)) 
                    {
                        if ($cadastro != "true")
                        {
                            //$potato = shell_exec('../enc.sh');
                            //echo $potato;
                            include 'conecta.php';
                            if($connect)
                            {
                                //echo "<br>Conectou";
                                $comando = pg_query("SELECT * FROM acesso");
                                $matriz_resposta=pg_fetch_array($comando);
                                //echo "<table border='1'><tr><td>uid</td></tr>";
                                while ($matriz_resposta)
                                {
                                    $nome = $matriz_resposta['adm'];
                                    $nome = (trim($nome));
                                    if ( $nome == $pid )
                                    {
                                        $adm = 'true';
                                    }
                                    $matriz_resposta=pg_fetch_array($comando);
                                }
                                pg_close($connect);
                                
                                //echo "<br> Desconectou";
                            }
                            else
                            {
                                echo "<br>Erro";
                            }
                            //if($adm=='true'){
/* Alterado por Vagner em 16/04/2018 */
			      if(1){ 
                                include 'conecta.php';
                                if ($connect)
                                {
    echo('<h4 align="center">Tabela com os IPs dos computadores que est&atildeo ligados</h4>
        <table align="center" border="3" style="border-collapse:collapse;"><tbody>
        <tr>
        <td>Sala Q201</td>
        <td>Sala Q210</td>
        <td>Sala Q212</td>
        <td>Sala Q307</td></tr><tr>
        <td>');
    while (@ ob_end_flush()); 
    $proc = popen("/home/todos/alunos/ct/a1716980/progs/login/encontra_novo q201", 'r');
    $live_output     = "";
    while (!feof($proc))
    {
        $live_output     = fread($proc,100);
        echo "$live_output<br>";
        @ flush();
    }
    pclose($proc);
    echo('</td><td>');
    while (@ ob_end_flush()); 
    $proc = popen("/home/todos/alunos/ct/a1716980/progs/login/encontra_novo q210", 'r');
    $live_output     = "";
    while (!feof($proc))
    {
        $live_output     = fread($proc,100);
        echo "$live_output<br>";
        @ flush();
    }
    pclose($proc);
    echo('</td><td>');
    while (@ ob_end_flush()); 
    $proc = popen("/home/todos/alunos/ct/a1716980/progs/login/encontra_novo q212", 'r');
    $live_output     = "";
    while (!feof($proc))
    {
        $live_output     = fread($proc,100);
        echo "$live_output<br>";
        @ flush();
    }
    pclose($proc);
    echo('</td><td>');
    while (@ ob_end_flush()); 
    $proc = popen("/home/todos/alunos/ct/a1716980/progs/login/encontra_novo q307", 'r');
    $live_output     = "";
    while (!feof($proc))
    {
        $live_output     = fread($proc,100);
        echo "$live_output<br>";
        @ flush();
    }
    pclose($proc);
    echo('</td></tr>
         </tbody></table>');
    echo('<table align="center">
        <tbody>
        <tr>
        <td style="size:5">Fecha janela atual:</td> <?php // Alterado por Vagner em 16/04/2018 ?>
        <td>
        <form action="https://200.134.25.52/conlab/login/" method="post"><td> <?php // Alterado por Vagner em 16/04/2018 ?>
        <input type="submit" name="ips" value="Fechar" onclick="closeSelf();"/> <?php // Alterado por Vagner em 16/04/2018 ?>
        </td>
        <td>
        </form>
        </td></tr></tbody></table>
        ');
                                    pg_close($connect);
                                }
                            }                           
                        }
                        else
                        {
                            echo "Cadastro";
                            unset($_SESSION['credential']);
                            //include ''
                        }       
                    } 
                    else 
                    {
                    //print('Falha na Autentica&ccedil;&atilde;o');
                        header("Location: negado.html");
                    }
                } 
                else 
                {
                    ldap_free_result($result);
                    ldap_close($ldap);
                    // print('Usu&aacute;rio n&atilde;o encontrado na Base LDAP');
                    header("Location: negado.html");
                }
                ldap_free_result($result);

            } 
            else 
            {
                ldap_close($ldap);
                // print('Erro ocorreu na busca da Base LDAP');
                header("Location: negado.html");
            }
            ldap_close($ldap);
        } 
        else 
        {
            // print('N&atilde;o foi poss&iacute;vel conectar ao host '.$host);
            header("Location: negado.html");
        }
    //echo('<p>passou aqui</p>');
    }
?>
</body>
</html>
<?php

?>
</body>
</html>
