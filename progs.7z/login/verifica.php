<html>
<head><title>Gerenciador de M&aacute;quinas</title>
<style type="text/css">
    table {border-collapse:collapse}
</style>
<script language="javascript">
    function send(str){
        document.getElementById(str).submit();
    }
</script>
</head>
<body>
<?php
// check to make sure that the site is secure
//if ($_SERVER["HTTP_HOST"]!="secure.hosting.vt.edu") {
//Header("Location: https://secure.hosting.vt.edu/".$_SERVER["HTTP_HOST"].$_SERVER["PHP_SELF"]);
//}
$host = 'ldaps://ldapslave.ct.utfpr.edu.br/';
$baseDn = 'dc=utfpr,dc=edu,dc=br';
$pid = $_POST['pid']; // get these values explicitly from the POST
$credential = $_POST['password'];
$acao = $_POST[acao];
$cadastro = $_POST[cadastro];
$master='false';
//$PCLIGADO=null;
session_start();
if (empty($_POST['password']))
{
    $credential = $_SESSION['credential'];
}
else
{
    $_SESSION['credential'] = $_POST['password'];
}

if (  $acao != 'at-q201' && $acao != 'at-q210' && $acao != 'at-q212' && $acao != 'd-q201' && $acao != 'd-q210' && $acao!='d-q212' && $acao!='d-q307' && $acao!='r-q201' && $acao!='r-q210' && $acao!='r-q212')
{
    /*ldap will bind anonymously, make sure we have some credentials*/
    if (isset($pid) && $pid != '' && isset($credential))
    {
        $ldap = ldap_connect($host);
        ldap_set_option($ldap, LDAP_OPT_PROTOCOL_VERSION, 3);
        ldap_start_tls($ldap);
        if (isset($ldap) && $ldap != '')
        {
            /* search for pid dn */
            $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('dn'));
            if ($result != 0)
            {
                $entries = ldap_get_entries($ldap, $result);
                $principal = $entries[0]['dn'];
                $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('cn'));
                $entries = ldap_get_entries($ldap, $result);
                $usuario = $entries[0]['cn'][0];
                if (isset($principal))
                {
                    /* bind as this user */
                    if (@ldap_bind($ldap, $principal, $credential))
                    {
                        if ($cadastro != "true")
                        {
                            include 'conecta.php';
                            if($connect)
                            {
                                $comando = pg_query("SELECT * FROM acesso");
                                $matriz_resposta=pg_fetch_array($comando);
                                while ($matriz_resposta)
                                {
                                    $nome = $matriz_resposta['adm'];
                                    $nome = (trim($nome));
                                    if ( $nome == $pid )
                                    {
                                        $adm = 'false';
                                        $master='true';
                                        $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('cn'));
                                        $entries = ldap_get_entries($ldap, $result);
                                        $usuario = $entries[0]['cn'][0];
                                    }
                                    $matriz_resposta=pg_fetch_array($comando);
                                }
                                if($master=='false')
                                {
                                    $comando = pg_query("SELECT * FROM professores");
                                    $matriz_resposta=pg_fetch_array($comando);
                                    while ($matriz_resposta)
                                    {
                                        $nome = $matriz_resposta['uid'];
                                        $nome = (trim($nome));
                                        if ( $nome == $pid )
                                        {
                                            $ano=$matriz_resposta['ano'];
                                            if($ano==date('Y'))
                                            {
                                                $diadasemana=$matriz_resposta['diasemana'];
                                                $diadasemana=(trim($diadasemana));
                                                if ( $diadasemana == date('l') )
                                                {
                                                    $horafim=$matriz_resposta['horafim'];
                                                    $horafim=(trim($horafim));
                                                    if(time()<strtotime($horafim))
                                                    {
                                                        $horainicio=$matriz_resposta['horainicio'];
                                                        $horainicio=(trim($horainicio));
                                                        if(time()>strtotime($horainicio))
                                                        {
                                                            $adm='true';
                                                            $master='false';
                                                            $sala=$matriz_resposta['sala'];
                                                            $sala=(trim($sala));
                                                            $result = @ldap_search($ldap, $baseDn, 'uid='.$pid, array('cn'));
                                                            $entries = ldap_get_entries($ldap, $result);
                                                            $usuario = $entries[0]['cn'][0];
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        $matriz_resposta=pg_fetch_array($comando);
                                    }
                                }
                                pg_close($connect);
                            }

                            else
                            {
                                echo('<br><h2 style="text-align: center;">Bem vindo ao gerenciador de m&aacutequinas do Daeln,<br>'.$usuario.'</h1><br>
                                     <table align="center">
                                     <tbody>
                                     <tr><td style="size:5">Erro ao acessar o banco de dados psql, favor verificar o problema</td></tr>
                                     <tr><td style="size:5">ou contactar um respons&aacutevel.</td>
                                     </tr></tbody></table>');
                            }
                            if($master=='true')
                            {
                                echo('<br><h2 style="text-align: center;">Bem vindo ao gerenciador de m&aacutequinas do Daeln,<br>'.$usuario.'</h1><br>
                                     <table align="center" border=1>
                                     <tbody>
                                     <tr>
                                     <td style="size:5">Insira uma a&ccedil&atildeo que voc&ecirc; deseja fazer:</td>
                                     <form id="m_opt_form" action="verifica.php" method="post"><td>
                                     <select name="acao" onchange="send(\'m_opt_form\')" >
                                     <option value="">Selecione uma a&ccedil&atildeo</option>
                                     <option value="d">Desligar</option>
                                     <option value="r">Reiniciar</option>
                                     <option value="a">Atualizar</option>
                                     </select>
                                     <input name="password" type="hidden" value='.$credential.'>
                                     <input name="pid" type="hidden" value='.$pid.'>
                                     </td> </form> </tr>');
                                     //<td>
                                     //<input name="password" type="hidden" value='.$credential.'>
                                     //<input name="pid" type="hidden" value='.$pid.'>
                                     //<input type="submit" name="FAZER" value="Enviar">
                                     //</form>
                                     //</td></tr>
                                     //');
                            }
                            if($adm=='true')
                            {
                                echo('<br><h2 style="text-align: center;">Bem vindo ao gerenciador de m&aacutequinas do Daeln,<br>'.$usuario.'</h1><br>
                                     <table align="center" border=1>
                                     <tbody>
                                     <tr>
                                     <td style="size:5">Insira uma a&ccedil&atildeo que voc&ecirc; deseja fazer:</td>
                                     <form id="a_opt_form" action="verifica.php" method="post"><td>
                                     <select name="acao" onchange="send(\'a_opt_form\')">
                                     <option value="">Selecione uma a&ccedil&atildeo</option>
                                     <option value="d">Desligar</option>
                                     <option value="r">Reiniciar</option>
                                     </select>
                                     </td> </form> </tr>');
                                     //<td>
                                     //<input name="password" type="hidden" value='.$credential.'>
                                     //<input name="pid" type="hidden" value='.$pid.'>
                                     //<input type="submit" name="FAZER" value="Enviar">
                                     //</form>
                                     //</td></tr>
                                     //');
                            }

                            if(isset($_POST['acao']))
                            {
                                if($master=='true' || $adm=='true')
                                {
                                    //echo('<table align="center"><tbody>');
                                    switch($acao)
                                    {
                                    case 'd':
                                        echo('<tr><td> Qual sala voc&ecirc deseja desligar: </td>
                                             <form id="m_sala_form" action="verifica.php" method="post"><td>
                                             <select name="acao" onchange="send(\'m_sala_form\')">
                                             <option value="">Selecione uma a&ccedil&atildeo</option>
                                             <option value="d-q201">Desligar Q201</option>
                                             <option value="d-q210">Desligar Q210</option>
                                             <option value="d-q212">Desligar Q212</option>
                                             <option value="d-q307">Desligar Q307</option>
                                             </select>
                                             <input name="password" type="hidden" value='.$credential.'>
                                             <input name="pid" type="hidden" value='.$pid.'>
                                             </td> </form> </tr>');
                                             //<td>
                                             //<input type="submit" name="FAZER" value="Enviar">
                                             //</form>
                                             //</td></tr>');
                                        break;
                                    case 'r':
                                        echo('<tr><td> Qual sala voc&ecirc deseja reiniciar: </td>
                                             <form id="m_sala_form" action="verifica.php" method="post"><td>
                                             <select name="acao" onchange="send(\'m_sala_form\')">
                                             <option value="">Selecione uma a&ccedil&atildeo</option>
                                             <option value="r-q201">Reiniciar Q201</option>
                                             <option value="r-q210">Reiniciar Q210</option>
                                             <option value="r-q212">Reiniciar Q212</option>
                                             </select><br>
                                             <input name="password" type="hidden" value='.$credential.'>
                                             <input name="pid" type="hidden" value='.$pid.'>
                                             </td> </form> </tr>');
                                             //<td>
                                             //<input type="submit" name="FAZER" value="Enviar">
                                             //</form>
                                             //</td></tr>');
                                        break;
                                    case 'a':
                                        echo('<tr><td> Qual sala voc&ecirc atualizar: </td>
                                             <form id="m_sala_form" action="verifica.php" method="post"><td>
                                             <select name="acao" onchange="send(\'m_sala_form\')">
                                             <option value="">Selecione uma a&ccedil&atildeo</option>
                                             <option value="at-q201">Atualizar Q201</option>
                                             <option value="at-q210">Atualizar Q210</option>
                                             <option value="at-q212">Atualizar Q212</option>
                                             </select><br>
                                             <input name="password" type="hidden" value='.$credential.'>
                                             <input name="pid" type="hidden" value='.$pid.'>
                                             </td> </form> </tr>');
                                             //<td>
                                             //<input type="submit" name="FAZER" value="Enviar">
                                             //</form>
                                             //</td></tr>');
                                        break;
                                        /*default
                                        break;*/
                                    }
                                }//fecha o if do master
                                else
                                {
                                    switch($acao)
                                    {
                                    case 'd':
                                        echo('<tr><td> Qual sala voc&ecirc deseja desligar: </td>
                                             <form id="a_sala_form" action="verifica.php" method="post"><td>
                                             <select name="acao" onchange="send(\'a_sala_form\')">
                                             <option value="">Selecione uma a&ccedil&atildeo</option>');
                                        if($sala=='q201')
                                        {
                                            echo('<option value="d-q201">Desligar Q201</option>');
                                        }
                                        if($sala=='q210')
                                        {
                                            echo('<option value="d-q210">Desligar Q210</option>');
                                        }
                                        if($sala=='q212')
                                        {
                                            echo('<option value="d-q212">Desligar Q212</option>');
                                        }
                                        if($sala=='q307')
                                        {
                                            echo('<option value="d-q307">Desligar Q307</option>');
                                        }
                                        echo('</select>
                                             </td>
                                             <td>
                                             <input type="submit" name="FAZER" value="Enviar">
                                             </form>
                                             </td></tr>');
                                        break;
                                    case 'r':
                                        echo('<tr><td> Qual sala voc&ecirc deseja reiniciar: </td>
                                             <form id="a_sala_form" action="verifica.php" method="post"><td>
                                             <select name="acao" onchange="send(\'a_sala_form\')">
                                             <option value="">Selecione uma a&ccedil&atildeo</option>');
                                        if($sala=='q201')
                                        {
                                            echo('<option value="r-q201">Reiniciar Q201</option>');
                                        }
                                        if($sala=='q210')
                                        {
                                            echo('<option value="r-q210">Reiniciar Q210</option>');
                                        }
                                        if($sala=='q212')
                                        {
                                            echo('<option value="r-q212">Reiniciar Q212</option>');
                                        }
                                        echo('</select><br>
                                             </td>
                                             <td>
                                             <input type="submit" name="FAZER" value="Enviar">
                                             </form>
                                             </td></tr>');
                                        break;
                                    }
                                }//fecha o else do master
                                //echo('</tbody>
                                //     </table>');
                            }
                            echo ('
                                  <tr>
                                  <td style="size:5">Clique no bot&atildeo Live para verificar quais computadores est&atildeo ligados:</td>

                                  <form action="pings.php" method="post" target="_blank"><td>
                                  <input name="password" type="hidden" value='.$credential.'>
                                  <input name="pid" type="hidden" value='.$pid.'>
                                  <input type="submit" name="ips" value="Live">
                                  </td>
                                  
                                  </form>
                                  </tr></tbody></table>
                                  <br>
                                  <table align="center"><tr><td>
                                  <form align="center" action="index.php" method="post">
                                  <input align="center" type="submit" name="Sair" value="Sair">
                                  </form></td></tr>
                                  </table>');
                            /*if($master=='true'){
                            	echo('<h4 align="center">Tabela com os IPs dos computadores que est&atildeo ligados</h4>
                            	<table align="center" border="3"><tbody>
                            	<tr>
                            	<td>Sala Q201</td>
                            	<td>Sala Q210</td>
                            	<td>Sala Q212</td>
                            	<td>Sala Q307</td></tr><tr>
                            	<td>');
                            while (@ ob_end_flush());
                            $proc = popen("/home/todos/alunos/ct/a1488147/ldap/encontra_novo q201", 'r');
                            $live_output     = "";
                            while (!feof($proc))
                            {
                                $live_output     = fread($proc,100);
                                echo "$live_output<br>";
                                @ flush();
                            }
                            pclose($proc);
                            echo('</td><td>');
                            while (@ ob_end_flush());
                            $proc = popen("/home/todos/alunos/ct/a1488147/ldap/encontra_novo q210", 'r');
                            $live_output     = "";
                            while (!feof($proc))
                            {
                                $live_output     = fread($proc,100);
                                echo "$live_output<br>";
                                @ flush();
                            }
                            pclose($proc);
                            echo('</td><td>');
                            while (@ ob_end_flush());
                            $proc = popen("/home/todos/alunos/ct/a1488147/ldap/encontra_novo q212", 'r');
                            $live_output     = "";
                            while (!feof($proc))
                            {
                                $live_output     = fread($proc,100);
                                echo "$live_output<br>";
                                @ flush();
                            }
                            pclose($proc);
                            echo('</td><td>');
                            while (@ ob_end_flush());
                            $proc = popen("/home/todos/alunos/ct/a1488147/ldap/encontra_novo q307", 'r');
                            $live_output     = "";
                            while (!feof($proc))
                            {
                                $live_output     = fread($proc,100);
                                echo "$live_output<br>";
                                @ flush();
                            }
                            pclose($proc);
                            echo('</td></tr>
                            	</tbody></table>');
                            }
                            else{
                            	echo('<h4 align="center">Tabela com os IPs dos computadores que est&atildeo ligados</h4>
                            	<table align="center" border="3"><tbody>
                            	<tr>
                            	<td>Sala Q201</td>');
                            	echo $sala;
                                echo('</tr><tr>
                            	<td>');
                            	while (@ ob_end_flush());
                                $proc = popen('/home/todos/alunos/ct/a1488147/ldap/encontra_novo '.$sala.'', 'r');
                                $live_output     = "";
                                while (!feof($proc))
                                {
                                $live_output     = fread($proc,100);
                                echo "$live_output<br>";
                                @ flush();
                                }
                            	echo('</td></tr>
                            	</tbody></table>');
                            }*/

                            if ( $master == 'true' )
                            {
                                include 'conecta.php';
                                if ($connect)
                                {
                                    $comando2 = pg_query("SELECT * FROM acesso");
                                    $matriz_resposta2=pg_fetch_array($comando2);
                                    echo("<br><center><h4>Clique na pessoa que voc&ecirc deseja revogar as permiss&otildees</h4><br>");
                                    echo('<form action="testebuscadados.php" method="post">');
                                    echo('<table allign="center" border=1 >');
                                    $i = 1;
                                    while ($matriz_resposta2)
                                    {
                                        $nome2 = $matriz_resposta2['adm'];
                                        $nome2 = trim($nome2);
                                        $procuraadm = @ldap_search($ldap, $baseDn, 'uid='.$nome2, array('cn'));
                                        $entriesadm = ldap_get_entries($ldap, $procuraadm);
                                        $nomeadm = $entriesadm[0]['cn'][0];
                                        //echo "$nome2<br>";
                                        //echo "$nomeadm<br>";
                                        echo('<tr>');
                                        echo "<td><input type='checkbox' name='remove$i' value='$i'></td><td>".$nomeadm."</td></tr>";
                                        $matriz_resposta2 = pg_fetch_array($comando2);
                                        $i = ($i + 1);
                                    }
                                    echo('</table>');
                                    echo('<input type="hidden" name="remove" value="1">');
                                    echo('<br><input type="submit" value="Remove" align="center"></form>');
                                    pg_close($connect);
                                }
                                echo ('<form action="authcheck2-TESTE.php" method="post">
                                      <input type="hidden" name="cadastro" value="true">
                                      <input type="hidden" name="pid" value='.$pid.'>
                                      <input type="submit" name="Submit" value="Cadastro"></form></center>');

                            }
                        }
                        else
                        {
                            echo "Cadastro";
                            unset($_SESSION['credential']);
                            //include ''
                        }
                    }
                    else
                    {
                        print('Falha na Autentica&ccedil;&atilde;o');
                        header("Location: negado.html");
                    }
                }
                else
                {
                    ldap_free_result($result);
                    ldap_close($ldap);
                    //print('Usu&aacute;rio n&atilde;o encontrado na Base LDAP');
                    header("Location: negado.html");
                }
                ldap_free_result($result);

            }
            else
            {
                ldap_close($ldap);
                //print('Erro ocorreu na busca da Base LDAP');
                header("Location: negado.html");
            }
            ldap_close($ldap);
        }
        else
        {
            //print('N&atilde;o foi poss&iacute;vel conectar ao host '.$host);
            header("Location: negado.html");
        }
        //echo('<p>passou aqui</p>');
    }
    else
    {
        header("Location: negado.html");
    }
}
else
{

    $minuto=time()/60 % 60;
    for($i=0; $i<=60; $i=$i+5)
    {
        if(($i-$minuto)>0 && ($i-$minuto)<5)
        {
            if(($i % 2)==0)
            {
                $tempodesliga=$i-$minuto+5;

            }
            else
            {
                $tempodesliga=$i-$minuto;
            }
        }
        if(($i-$minuto)==0)
        {
            $tempodesliga=10;
        }

    }
    if ( $acao == 'at-q201' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q201 ser&atilde;o atualizados em ".$tempodesliga." minutos</h4>";
        //shell_exec("/home/todos/alunos/ct/a1488147/ldap/update q201");
        shell_exec('/bin/touch /home/todos/alunos/ct/a1488147/ldap/update q201');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'at-q210' )
    {
        echo("teste");
        echo "<br><br><h4 align='center'>Os computadores da sala Q210 ser&atilde;o atualizados em ".$tempodesliga." minutos</h4>";
        shell_exec("/home/todos/alunos/ct/a1488147/ldap/update q201");
        //shell_exec('/bin/touch /home/todos/alunos/ct/a1488147/ldap/update q210');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'at-q212' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q201 ser&atilde;o atualizados em ".$tempodesliga." minutos</h4>";
        shell_exec("/home/todos/alunos/ct/a1488147/ldap/update q201");
        //shell_exec('/bin/touch /home/todos/alunos/ct/a1488147/ldap/update q212');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'd-q201' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q201 serao desligados em ".$tempodesliga." minutos</h4>";
        shell_exec('/bin/touch /home/alunos/share/sistema/desliga-q201');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'd-q210' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q210 serao desligados em ".$tempodesliga." minutos</h4>";
        shell_exec('/bin/touch /home/alunos/share/sistema/desliga-q210');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'd-q212' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q212 serao desligados em ".$tempodesliga." minutos</h4>";
        shell_exec('/bin/touch /home/alunos/share/sistema/desliga-q212');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'd-q307' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q307 serao desligados em ".$tempodesliga." minutos</h4>";
        shell_exec('/bin/touch /home/alunos/share/sistema/desliga-q307');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'r-q201' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q201 serao reiniciados em ".$tempodesliga." minutos</h4>";
        shell_exec('/bin/touch /home/todos/alunos/ct/a1488147/ldap/reiniciar q201');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'r-q210' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q210 serao reiniciados em ".$tempodesliga." minutos</h4>";
        shell_exec('/bin/touch /home/todos/alunos/ct/a1488147/ldap/reiniciar q210');
        header("Refresh: 2, index.php");
    }
    if ( $acao == 'r-q212' )
    {
        echo "<br><br><h4 align='center'>Os computadores da sala Q212 serao reiniciados em ".$tempodesliga." minutos</h4>";
        shell_exec('/bin/touch /home/todos/alunos/ct/a1488147/ldap/reiniciar q212');
        header("Refresh: 2, index.php");
    }
}

#FUNCAO PARA PRINTAR O A SAIDA DO COMANDO
function liveExecuteCommand($cmd)
{

    while (@ ob_end_flush()); // end all output buffers if any

    $proc = popen("$cmd 2>&1", 'r');

    $live_output     = "";
    $complete_output = "";

    while (!feof($proc))
    {
        $live_output     = fread($proc,1000);
        $complete_output = $complete_output . $live_output;
        $tamanho=strlen($live_output);
        echo "$live_output<br>";
        //echo "$tamanho<br>";
        @ flush();
    }
    //echo "$complete_output<br>";
    pclose($proc);

    // get exit status
    //preg_match('/[0-9]+$/', $complete_output, $matches);

    // return exit status and intended output
    return array (
               'exit_status'  => $matches[0],
               'output'       => str_replace("Exit status : " . $matches[0], '', $complete_output)
           );
}
?>
</body>
</html>
