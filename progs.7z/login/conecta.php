<?php
$string_connect = "host=localhost port=5432 dbname=estagio user=estagio password=&st@g10.";
$connect = pg_connect($string_connect);
?>